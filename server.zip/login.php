<html>
<body>
<?php
    $user = $_GET["username"];
    $pass = $_GET["pwd"];
	if($user === 'admin' AND $pass === '123'){
		header("Location:homee.html");
	}else{
		header("Location:page10.html");
	}
?>
</body>
</html>
