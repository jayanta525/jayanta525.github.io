<html>
<body>

<?php
    $client = $_GET["client"]; //You have to get the form data
    $access = $_GET["access"];
    $file = fopen('new/index.html', 'w+'); //Open your .txt file
    ftruncate($file, 0); //Clear the file to 0bit
    $content = $client.$access. PHP_EOL;
    fwrite($file , $content); //Now lets write it in there
    fclose($file ); //Finally close our .txt
    die(header("Location: ".$_SERVER["HTTP_REFERER"]));
?>
</body>
</html>
