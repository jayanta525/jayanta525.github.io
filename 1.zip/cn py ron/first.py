import socket

def m_info():
#	host_name=socket.gethostname()
	host_ip=socket.gethostbyname("www.facebook.com")
	print (host_ip)


if __name__=='__main__':
	m_info()
	
