import socket
from binascii import hexlify

def convert_ipv4_add():
	for ip_addr in ['127.0.0.1', '192.168.60.1']:
		pack_ip_addr = socket.inet_aton(ip_addr)
		unpack_ip_addr = socket.inet_ntoa(pack_ip_addr)
		print ("ip address : %s" %ip_addr)
		print ("packed address : %s" %pack_ip_addr)
		print ("packed address in hex : %s" %hexlify(pack_ip_addr))
		print ("unpacked address : %s" %unpack_ip_addr)

if __name__=='__main__':
	convert_ipv4_add()  
