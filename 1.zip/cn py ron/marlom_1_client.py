import socket
import argparse as ap

host = "localhost"

def client(port):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	server_addr = (host, port)
	sock.connect(server_addr)

	try:
		msg = input("Enter Message:")
		print ("Sending data: %s" %msg)
		sock.sendall(msg.encode("UTF-8"))
		data_received = 0
		data_expected = len(msg)
		
		while data_received < data_expected:
			data = sock.recv(18)
			data_received += len(data)
			print ("Received: %s" %data)
	
	except socket.error as error:
		print ("Socket Error: %s" %str(error))
	except Exception as ex:
		print("Other Exception: %s" %str(ex))
		sock.close()				

if __name__ == "__main__":
	parser = ap.ArgumentParser(description = "TCP SEVER")
	parser.add_argument("--port", action = "store", type = int, dest = "port", required = True)
	given_args = parser.parse_args()
	port = given_args.port
	client(port)
