#
import socket
import sys

def reuse_socket_addr():
	sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	old_state=sock.getsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR)
	print("old state %s"%old_state)
	sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
	new_state=sock.getsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR)
	print("old state %s"%new_state)
	local_port=8282
	srv=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
	srv.bind(('',local_port))
	srv.listen(1)
	print("Listening on port %s"%local_port)

	#since server is listening everytime
	while(True):
		try:
			connection,addr = srv.accept()
			print("connected by %s %s"%(addr[0],addr[1]))
	
		except KeyboardInterrupt:
				break
		except Socket.error as msg:
				print (msg)

if __name__ == '__main__':
	reuse_socket_addr()
