import socket
import argparse as ap

host = "localhost"
backlog = 5
payload = 2048

def server(port):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	server_addr = (host, port)
	print ("Creating server %s at %s" %server_addr)
	sock.bind(server_addr)
	sock.listen(backlog)

	while True:
		print ("Waiting for Client...")
		client, addr = sock.accept()
		data = client.recv(payload)

		d = str(data)
		
		if data:
			if d == "END":
				print ("Connection ended!")
				sock.close()

			print ("Receiving %s" %data)
			print (type(data))
			client.send(data)
			print ("Sending %s to %s" %(data, addr))
		client.close()

if __name__ == "__main__":
	parser = ap.ArgumentParser(description = "TCP SEVER")
	parser.add_argument("--port", action = "store", type = int, dest = "port", required = True)
	given_args = parser.parse_args()
	port = given_args.port
	server(port)
