import socket
from binascii import hexlify
def convert_ipv4_address():
   for ip_addr in ['127.0.0.1','192.168.62.1']:
      packed_ip_addr=socket.inet_aton(ip_addr)
      unpacked_ip_addr=socket.inet_ntoa(packed_ip_addr)
      print("IP address : %s"%ip_addr)
      print("Packed IP address : %s"%packed_ip_addr)
      print("UnPacked IP address : %s"%unpacked_ip_addr)
if __name__=='__main__':
   convert_ipv4_address()
