import socket
def finding_service_name():
   protocol_name='tcp'
   for port in [80,25,23]:
      print("Port : %s --> Service: %s"%(port,socket.getservbyport(port,protocol_name)))
   
if __name__=='__main__':
   finding_service_name()
