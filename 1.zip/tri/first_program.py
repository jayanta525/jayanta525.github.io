import socket
def print_machine_info():
   #host_name=socket.gethostname()
   host_ip=socket.gethostbyname("www.google.com")
   #print ("host_name:%s"%host_name)
   print ("host_ip:%s"%host_ip)
if __name__=='__main__':
   print_machine_info()
