import http.server
import socketserver
port=8281
Handler=http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("",port),Handler) as httpd:
   print("serving a port %s"%port)
   httpd.serve_forever()

