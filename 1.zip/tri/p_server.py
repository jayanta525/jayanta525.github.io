#!/usr/bin/python
import socket
s=socket.socket()
host=socket.gethostname()
port=12341
s.bind(('192.168.62.90',port))
s.listen(5)
while True:
   c,addr=s.accept()
   print 'got connection from',addr
   c.send('thankyou for your connection')
   num = 7

   # uncomment to take input from the user
   #num = int(input("Enter a number: "))

   factorial = 1

   # check if the number is negative, positive or zero
   if num < 0:
      print("Sorry, factorial does not exist for negative numbers")
   elif num == 0:
      print("The factorial of 0 is 1")
   else:
      for i in range(1,num + 1):
       factorial = factorial*i
   c.send("The factorial of",num,"is",factorial)
   c.close()
   
